type propsType={
    addDialog:boolean,
    editDialog:boolean,
}
export default function Dialogs(props:propsType){
    
    return (
        <div>

        </div>
    )
}
export type userType={
    user:string,
    password:string
}